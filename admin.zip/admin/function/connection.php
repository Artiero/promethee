<?php
$conn = mysqli_connect('localhost','root','root','db_promethee');
?>